<?php

$user   = "root";
$pass   = "";
$host   = "localhost";
$bd     = "actividad";
